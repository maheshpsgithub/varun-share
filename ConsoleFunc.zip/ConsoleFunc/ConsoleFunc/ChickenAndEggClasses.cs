﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleFunc
{
    public interface IBird
    {
        Egg Lay();
    }

    public class Chicken : IBird
    {
        public bool isLayed = false;

        public Egg Lay()
        {
            if (!this.isLayed)
            {
                this.isLayed = true;
                return new Egg(getParent);
            }
            else
            {
                throw new InvalidOperationException();
            }

        }

        public IBird getParent()
        {
            return this;
        }
    }

    public class Egg
    {
        private IBird parentBird;
        public Egg(Func<IBird> createChicken)
        {
            this.parentBird = createChicken();
            //throw new NotImplementedException();
        }

        public IBird Hatch()
        {

            if (this.parentBird is Chicken)
                return new Chicken();
            else
                throw new NotImplementedException();
        }
    }
}
