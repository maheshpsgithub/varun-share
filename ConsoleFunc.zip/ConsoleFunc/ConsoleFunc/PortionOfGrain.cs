﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleFunc
{
    class PortionOfGrain
    {
        public static Dictionary<string, float> Storage = new Dictionary<string, float>();
        public static float totalWeight;

        public static void Add(string grain, float weight) {
            if (!Storage.ContainsKey(grain))
            {
                Storage.Add(grain, weight);
                
            }
            else
            {
                Storage[grain] = Storage[grain] + weight;
            }

            totalWeight = totalWeight + weight;
        }

        public static float GetProportion(string grain) {
            return Storage[grain] / totalWeight;
        }
    }
}
