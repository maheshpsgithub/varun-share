﻿using System;
using System.Linq;

namespace ConsoleFunc
{


    class Program
    {

        static string GetConversion()
        {
            string result = "";
            string s = "rw--w-r-x";
            //char[] cr = s.ToCharArray();

            char[] cr = s.Select(x => x == '-' ? '0' : '1').ToArray();

            string numStr = "";

            for (int i = 1; i <= cr.Length; i++)
            {
                numStr = numStr + cr[i - 1];
                if (i % 3 == 0)
                {
                    result = result + Convert.ToInt32(numStr, 2);
                    numStr = "";
                }

            }
            return result;

        }

        static void Main(string[] args)
        {
            var chicken1 = new Chicken();
            var egg = chicken1.Lay();
            var childChicken = egg.Hatch();
            Console.WriteLine("Chicken and Egg example:");
            Console.WriteLine("Chicken1 Layed an Egg. " + egg.ToString());

            Console.WriteLine("Child Chicken Hatched from an Egg. " + childChicken.ToString());

            try
            {
                var eggSecond = childChicken.Lay();
                Console.WriteLine("Child Chicken Layed an Egg. " + eggSecond.ToString());

            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Chicken1 has already Layed. Invalid Operation Exception");
            }

            Console.WriteLine("=========================================");
            Console.WriteLine("Get Storage Proportion example:");
            PortionOfGrain.Add("wheat", 600);
            PortionOfGrain.Add("wheat", 300);
            PortionOfGrain.Add("rice", 900);

            Console.WriteLine("wheat portion is:");
            Console.Write(PortionOfGrain.GetProportion("wheat") * 100);
            Console.Write("%");

            Console.WriteLine("=========================================");
            Console.WriteLine("rw--w-r-x equivalent decimal is :");
            Console.Write(GetConversion());
            Console.ReadKey();



        }
    }
}
