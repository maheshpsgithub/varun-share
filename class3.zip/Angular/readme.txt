# Angular

Angular is complete framework which can be use to build
mobile and web application

# Angular 
- One framework for building web and mobile application
- best for sinlge page application
- written in typescript
- simple an expressive
- component base architecture


# Angular Js or 1.x vs Angular 2 or above

Angular 2.x
- bootstrap function is used to start the application
- support pipe
- support camelcase syntex like ngClass, ngStyle
- uses html DOM for manuplation
- we dont have scope, factory
- support two way data binding using () and []



Angular JS or 1.x
- ng-app is used to start the application
- support filters
- support spinal case like ng-click, ng-class
- create its own DOM 
- we have scope, factory, servicea
- does not have any support for () and []


# Angular Building Block
> Modules
> Components
> Services
> Decorators
> Meta-data
> Pipes


# Angular cli
It is the powerfull tool used for building angular application
we can automate lot of thing with the help of angular cli
for radpid development angular cli is used
we can use angular cli
- to create new project
- to generate component, modules, servies


# How to setup env to start working with angular
> node
> npm
> angular/cli
> text editor > VSCode


# create first angular project
ng new angular-training
cd angular-training

ng serve  // run the project only
ng s
ng s -o  // run and open in the browser

default port for angular   4200


ng s -o --port 4000


# Angular Project Folder Structure
> package.json - this is the file which containes the list 
		of all dependencies

> Readme.Md - this the file where we can write some notes
              or instructions for the team

> e2e - this is the folder where we keep all code for
         end to end testing

> node_modules - npm will look into package.json file
               and download all the dependencies on 
                node_module folder. this is the biggest
              folder in your application.

> editor.conf - this is the configuration file
                used by editor

> gitignore - any file or folder if your want ignore while
              pushing the code to remote repo

> angular.json - this is application level angular configuration
                 file

> tsconfig - typescript configuration file

> src - main source code folder 

> assets - keep all your static content like images or any files

> environmant - contain environmant file to switch between the develop and prod env

> favicon - fav icon

> index.html - which finally serve on the browser

> karma.config - congif for karma

> main.ts - this is the main entry point for anglar app contain bootstrap module

> styles.css - global css file

> test.ts - main entry point for unit testing

> tsconfig.app.json

> tsconfig.spec.json

> app  - main folder which contain modules, components, services everything
          we require fr building angular application



Main.ts -> AppModule -> app.component.ts -> app.component.html


# Module
> Angular has its own modularity system called modules or
 ngModule
> Every angular app must have at least one root module
> every angular module we declare with @NgModule decorator
> decorator contain some meta data which inform angular
  framework how you want to process your typescript class
> Angular has built in module with @angular as prefix

angular module importanrt properties
- export
- import
- declaration
- providers
- bootstrap


import - specify the other dependent module which you want
         use in the entire application

declaration - all component, pipes you create we have register the root module
            we use this declaration block

bootstrap - this contain the name of the root component from which you want to
            start your application
providers - we register all the services















































