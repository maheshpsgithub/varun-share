# JavaScript
# Jquery

# Typescript
# Angular


# JavaScript

JavaScript is the programming langugae which is use fpr building
web application
Javascript is one of main 3 langugae we should know when buildingwe
we pages

- HTML
- CSS
- Javascript

JavaScript can be use to change the HTML cotent
Javascript can be use to change the CSS class
Javascript can be use to manipulate DOM

We can write JavaScript code in two ways
- Internal
- External


- Internal
we can write the JavaScript in code inside 
<head>
<body>
using

<script>
  // code
</script>


The most important function in JavaScript is
getElementById()
this is the function can be use to find any element
in out HTML page


# There are 4 ways you can write the content using Javascript\
1. alert()
2. Document.write()
3. Console.log()
4. innerHtml



# variable
variable are use to store some data which value can be change
during the execution of programe
In JavaScript varibales are not type safe means no datatype
is require at the time of declaring varibale
var a = 10;
var a = "Hello";

int a = 10;


# Loops
for
foreach
while
do while

# Conditional Statment
If
else
else if
switch

# DOM
Document object Model

# Jquery
Jquery is external library on top of JavaScript which gives
us additional methods and simple syntex to work on our wen pages

$.("selector").action()

$ - Jquery
selector  - element which you want to manipulate
action - which you want to take on element


# 3 ways to find the element
1 - element name
2 - class
3 - id



# event
click
dblclick
onload
..


# Effects
fadeIn
fadeOut
SlideIn
SLideOut
toggle
hide
show


# add and remove css class

















































