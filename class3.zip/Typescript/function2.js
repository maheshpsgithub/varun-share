var Dimenstion = /** @class */ (function () {
    function Dimenstion() {
    }
    Dimenstion.prototype.drawSquare = function () {
        console.log("Result:" + this.x + ", " + this.y + ", " + this.z);
    };
    return Dimenstion;
}());
var object = new Dimenstion();
object.x = 10;
object.y = 20;
object.z = 30;
object.drawSquare();
