
function addNumber(a, b){
    return a + b;
}

let result = addNumber(10, "number");

console.log(result);