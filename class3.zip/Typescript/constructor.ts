class Test{

    // private _x: number;
    // private _y: number;

    // constructor(x: number, y: number){
    //     this._x = x;
    //     this._y = y;
    // }

    constructor(private x: number, private y: number ){}

    add(){
        console.log(this.x);
    }


}


let test = new Test(10, 20)
test.add();


