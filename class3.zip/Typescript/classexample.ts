class Student{

    private _x;
    private name: string;
    private roll: number;
    private passMark: number = 40;

    get X{
        return this._x;
    }

    set X(value){
        this._x = value;
    }


    // setName(name){
    //     if(name==null){
    //         throw new Error("Not valid");
    //     }
    // }
    //  getName(){
    //      return this.name;
    //  }

    display(){
        console.log(`Result: ${this.name}, ${this.roll}, ${this.passMark}`);
    }
}

let std = new Student();


std.display();