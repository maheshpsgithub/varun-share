var Test = /** @class */ (function () {
    // private _x: number;
    // private _y: number;
    // constructor(x: number, y: number){
    //     this._x = x;
    //     this._y = y;
    // }
    function Test(x, y) {
        this.x = x;
        this.y = y;
    }
    Test.prototype.add = function () {
        console.log(this.x);
    };
    return Test;
}());
var test = new Test(10, 20);
test.add();
