var a = "Helo";
var b = 10;
var c = true;
var d = "";
var e = ["hello", "World"];
var f = [true, 10, "Hello"];
var colorRed = 1;
var colorGreen = 2;
var colorBlue = 3;
var Colors;
(function (Colors) {
    Colors[Colors["Green"] = 1] = "Green";
    Colors[Colors["Blue"] = 2] = "Blue";
    Colors[Colors["Yellow"] = 3] = "Yellow";
})(Colors || (Colors = {}));
var g = Colors.Blue;
