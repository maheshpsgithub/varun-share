function addNumber(a, b) {
    return a + b;
}
var result = addNumber(10, "humber");
console.log(result);
