function test() {
    for (var a = 1; a < 5; a++) {
        console.log(a);
    }
    console.log("Outside:" + a);
}
test();
