var Student = /** @class */ (function () {
    function Student() {
        this.passMark = 40;
    }
    Student.prototype.display = function () {
        console.log("Result: " + this.name + ", " + this.roll + ", " + this.passMark);
    };
    return Student;
}());
var std = new Student();
std.name = null;
std.roll = -1;
std.passMark = 30;
std.display();
