export class Point{
    constructor(private x, private y){}

    drawPoint(){
        console.log(`Point: ${this.x}, ${this.y}`);
    }
}


export class Point2{
    constructor(private x, private y){}

    drawPoint(){
        console.log(`Point: ${this.x}, ${this.y}`);
    }
}

export class Point3{
    constructor(private x, private y){}

    drawPoint(){
        console.log(`Point: ${this.x}, ${this.y}`);
    }
}