let a: string = "Helo";
let b: number = 10;
let c: boolean = true;
let d: any = "";

let e: string[] = ["hello", "World"];
let f: any[] = [true, 10, "Hello"];

const colorRed = 1;
const colorGreen = 2;
const colorBlue = 3;

enum Colors { Green = 1, Blue=2, Yellow=3 }

let g = Colors.Blue;






