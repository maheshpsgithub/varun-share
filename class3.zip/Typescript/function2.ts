class Dimenstion{
    x: number;
    y: number;
    z: number;

    drawSquare(){
        console.log(`Result:${this.x}, ${this.y}, ${this.z}`);
        
    }
}


let object = new Dimenstion();
object.x = 10;
object.y = 20;
object.z = 30;

object.drawSquare();