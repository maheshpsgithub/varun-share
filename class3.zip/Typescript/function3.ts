let message = function(name){
    console.log(name);
}


let message2 = (name) => {
    console.log(name)
}



let message3 = name => {
    console.log(name)
}

let sum = (a: number, b: number) => {
    a + b;
}

let test = () => {
    console.log("hello");
}