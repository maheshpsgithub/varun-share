# Day 1

HTML + CSS

HTML  - Hyper Text Markup Language

HTML5 - 2015

<doctype> - declaration for browser how to render a web page

# new features in HTML5
1. Semantic Tags
2. Form element and type
3. Local Storage
4. Canvas and SVG
5. Geo Location
6. Drag and Drop


# Semantic Tags
In the HTML 5 new sementaic tags were introduce
to provide better structure for your web page

<header>
<aside>
<footer>
<section>
<article>
<figure>
<nav>


# Form Elements
input type = 
text
number
range
date
time
month
week
color

# HTML tags

# h1 - heading 
most important text of your web page we can write inside h1

<h1>
<h2>
<h3>
<h4>
<h5>
<h6>

# <p>
paragraph will add line space and automatically break the line also
all the content you want to add in your web page must add in <p>

# <br>
line break

# <img>
it is use to add image in your web page
src - source of image
alt - alternative text
title - tooltip

# list
<ul> - under order list
<ol> - order list


# table
<table>
<tr> - table row
<td> - table data / cell
<th> - table heading
<thead>
<tbody>


# Forms

# HTML5 New API 
> Web Storage / local Storage
> GeoLocation
> Media - Audio / Video
> Graphics - SVG and Canvas
> Drag and Drop

# Web Storage
Web application can store some amount of data 
locally using web Storage

Earlier we arr using cookies to store some data

Per domain or orgin have their own web Storage
all the web page which belong to one domain
can access and manipulate same web Storage

unlike the cookies we can store more amount of
data in web storage

> Type of web storage
1. Local storage - it will store the data permanently
2. session storage - data will be there till browser is active


# Local Storage
> save data
localstorage.setItem("key", "value");
localstorage.key = value;

> get data
localstorage.getItem("key")
localstorage.key

> remove / clear
localstorage.clear()  // delete all
localstorage.removeItem("key")  // delete only one


# Session Storage
It is use to store data for a session the momemt you close browser tab
data will be lost 

> saving
sessionStorage.seItem("key", "value")
sessionStorage.key = value

> read data
sessionStorage.getItem("key")
sessionStorage.key


# GeoLocation
HTML 5 geolocation API is use to get the user 
geographical position

But since this is the matter of user privacy we cann
only able to access user position if user allows use
to do so

getcurrentlocation()


# Media
<audio>
<video>


# Drag and Drop
this is one of common features these days all the elements in HTML 5 are by
default draggable

# SVG
Sclabale vector graphics

SVG are use for high resolution images, logos and icons





























