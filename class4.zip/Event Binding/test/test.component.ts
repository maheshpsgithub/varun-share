import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <button (click)="onButtonClick($event)">Button</button>

  <button (dblclick)="onButtonClick($event)">Double Click</button>

  <h1 (click)="onButtonClick($event)">Hello</h1>

  `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {


  constructor() { }

  ngOnInit() {
  }

  onButtonClick(e){
    console.log(e.type);
  }







}
