import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  <h1 class="text-red"> Some Heading </h1>
  <h1 [class]="textRed">Some Other Heading</h1>

  <h1 [class.text-red]="hasError">Heading</h1>
  <h1 [ngClass]="multiClass" >Some Heading</h1>
  `,
  styles: [`
    .text-red{
      color: red
    }
    .text-green{
      color: green
    }
    .text-italic{
      font-style: italic
    }
  `]
})
export class TestComponent implements OnInit {

  public textRed = "text-red";
  public hasError = false;
  public isItalic = false;
  public multiClass = {
    'text-red': this.hasError,
    'text-green': !this.hasError,
    'text-italic': this.isItalic
  };

  constructor() { }

  ngOnInit() {
  }







}
