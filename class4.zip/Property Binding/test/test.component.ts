import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  <img src="https://www.iiht.com/wp-content/uploads/2018/11/iiht-logo1.png"/>

  <img [src]="imagePath" />
  <br><br>
  <button>Button</button>
  <button disabled>Button</button>
  <br>
  <br>

  <button disabled="{{ isDisabled }}" >Button</button>
  <button [disabled]="isDisabled" >Button</button>

  <br>
  <img src="{{ imagePath + image }}"/>
  <img [src]="imagePath"/>

  `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  public isDisabled = false;

  public imagePath = "https://www.iiht.com/wp-content/uploads/2018/11/";
  public image = "iiht-logo1.png";

  constructor() { }

  ngOnInit() {
  }




}
