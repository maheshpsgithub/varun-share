import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <h1 [style.color]="hasError ? 'red': 'green'">Some Heading</h1>
  <h1 [style.color]="markColor" >Some Other Heading</h1>
  <h1 [ngStyle]="titleStyle" >Title Heading</h1>
  `,
  styles: [`

  `]
})
export class TestComponent implements OnInit {

  public hasError = false;
  public markColor = "yellow";

  public titleStyle = {
    fontStyle: 'italic',
    color: 'red'
  }

  constructor() { }

  ngOnInit() {
  }







}
