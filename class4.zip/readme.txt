# Angular

Main.ts -> AppModule -> AppComponent

# Angular/cli
# FOlder Structure
# Modules

# Components
- A resuable UI segment visible to the end user
- Used to specify html elements and logic for user interaction

We can divide this component into 3 parts
1. Component class
2. Template
3. Decorator

Component   =  Component Class   +     Template     +   Decorator
		Typescript class       View or HTML     Meta Data 
		data and method


# decorator
- A function that ass meta data to a class
- these are prefix with @ symbol
- angular has build in decorator like @component for defining component


# Type of decorators
@component - used for defining component
@MgModule - used for defining modules
@Injectable - used for defining service
@Pipe - used for defining pipes


- MetaData
- tell angular how to process a class


# How to create component manually
# How to change bootsrap component
# How to nest component inside onther component
# how to write inline HTML
# How to write css
# How to create component using angular/cli
	
	ng generate component <component name>
	ng g c <component name>
# How to install bootstrap in angular application
	1. add bootstrap css CDN link in index.html
	2. install bootstrap using npm
		npm install bootstrap@latest --save
		add bootstrap.css in angular.json file
		dont forget to restart the server

# How to create a sample web page in angular app

# Data Binding
> One way data binding - from component class to view template
> one way data binding - from template to component class
> two way data binding - from component class to template and from template to 
                         component class



# One way data binding
from component class to template
> Interpolation
> Property binding


# Interpolation
{{  }}
we can use interpolation to evaluate expression
all javascript property and function can be used inside interpolation
we can call our custom methods also


# Property binding
when ever we want to bind any property of the element we have wrap the property
with the pair of square brackets -  []



Property binding vs interpolation
interpolation work well with string values
when we want to concatenate any string consider using interpolation

Property binding work well with non string value
when we are dealing with non string value for example boolen consider using property binding



# One way data binding
from template to component class
> Event binding



# Event Binding
from template to component class
for example: we want to send
event binding we can write the name of event
()
$event this is special or reserve keyword which 
contain the information of current event




# Class Binding
class binding is use when we want to apply any css class dynamically
[] - for class binding
when we want to apply css class consitionally
if we want to apply multiple css class for that angular provide a 
speical directive
[ngClass] - to be use when we want to apply multiple class


# Style Binding
style binding is use when we want to apply style consitionally
[]

























		























