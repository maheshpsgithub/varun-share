import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
  <h1>Welcome {{ name }}</h1>
  <h1>{{ 10 + 20 }}</h1>
  <h1>{{ name.length }}</h1>
  <h1>{{ name.toUpperCase() }}</h1>
  <h1>{{ 'Hello '+ name }}</h1>
  <h1>{{ welcome() }}</h1>
  `,
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {

  public name = "Mark Smith";

  constructor() { }

  ngOnInit() {
  }


  welcome(){
    return 'Hello from custom method: ' + this.name;
  }


}
