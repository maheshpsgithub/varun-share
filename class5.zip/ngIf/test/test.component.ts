import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <h1  *ngIf="displayName; then thenBlock; else elseBlock"></h1>

  <ng-template #thenBlock>
    <h1>Hello from if</h1>
  </ng-template>

  <ng-template #elseBlock>
    <h1>Hello from else</h1>
  </ng-template>

  <button *ngIf="isLogging">Login</button>
  <button *ngIf="!isLogging">Logout</button>


  `,
  styles: [`

  `]
})
export class TestComponent implements OnInit {

  public displayName = true;
  public isLoggin: boolean = false;


  constructor() { }

  ngOnInit() {
  }





}
