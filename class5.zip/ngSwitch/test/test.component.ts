import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `
<!--
  <div [ngSwitch]="color">
    <h1 *ngSwitchCase="'red'" >Red Color is selected</h1>
    <h1 *ngSwitchCase="'green'" >Green Color is selected</h1>
    <h1 *ngSwitchCase="'yellow'" >Yellow Color is selected</h1>
    <h1 *ngSwitchDefault >Not on the list</h1>
  </div>
-->

  <div [ngSwitch]="number">
    <h1 *ngSwitchCase="1" >One</h1>
    <h1 *ngSwitchCase="2" >Two</h1>
    <h1 *ngSwitchCase="3" >Three</h1>
    <h1 *ngSwitchDefault>Please select number between (1-3)</h1>
  </div>

  `,
  styles: [`

  `]
})
export class TestComponent implements OnInit {

  public color = 'black';
  public number = 4;


  constructor() { }

  ngOnInit() {
  }





}
