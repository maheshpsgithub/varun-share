import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  @Input('data') public name;

  @Output()
  public childEvent = new EventEmitter();


  onButtonClick(){
    this.childEvent.emit("Hi from Child Component");
  }



  constructor() { }

  ngOnInit() {
  }

}
