import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <input type="text" #myInput>
  <button (click)="onButtonClick(myInput)">Button</button>

  `,
  styles: [`

  `]
})
export class TestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  onButtonClick(input){
    console.log(input.value);
  }





}
