# Template Reference Variable

template reference variable are use to get the information
pf any element in your document 

we can declare template referenve variable using
#

# Two way data binding
when the data flow from component to template and
template to component

[] - property binding
() - event binding

[()] - two way data binding - banana in a box



# Structural Directives
When we add or remove html from the template

ngIf
ngSwitch
ngFor


#ngIf

#ngSwitch

#ngFor
This directive we use when we want to display a dunamic list
it is like for loop
when we want to execute some html in a loop

index
first
last
odd
even



# Problem 
1. ngFor directive may perform poorly with large data set
2. A small change in the list trigger a cascading of DOM manipulation


# Solution
# trackBy
using trackBy with ngFor directive we can able to recognize the
changes in the data set and we can reuse he dom element and recreate only
when we add new additional element


Steps
1. to specify a trackby function we need to create one in our component
2, the function get the index of the element and element itself
3. then we have to retrun the unique value of the element (like emp id)



# Pipes
Transform the data before it get display on the browser screen

Angular provides some build in pipes like Date, currency, uppercase etc
but we also have an option to create our own pipes


{{ 'hello' | 'uppercase' }}
{{ 'text' | <pipe name>: <parameter> }}

# Custom Pipe
1. create pipe class which implement PipeTransform interface
2. implment transform method
3. register pipe with root module
4. consume pipe in the component template

to generate pipe using angular/cli
   > ng g p <pipename>     // ng g p title


# Component Interaction
@Input
@Output

when we have a parent and child relation between the component and paranet
 and child component want to send some data between ech other we can use these two
decorators

NOte: @Input and @Output decorators can only be use when we have parent  and child
      relation between the component or when two component are nested they only   
      we can able to semd data between each other

@Input - parent want to send some data to child component

@Output - child want to send some data to parent component




































































