import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  // template: `
  //   <h1>{{ name }}</h1>
  //   <h1>{{ name | uppercase }}</h1>
  //   <h1>{{ name | titlecase }}</h1>
  //   <h1>{{ name | lowercase }}</h1>

  //   <h1>{{ name | slice:3:7  }}</h1>
  //   <h1>{{ person | json }}</h1>

  //   <h1>{{ 1.234 | number: '1.2-3'}}</h1>
  //   <h1>{{ 1.234 | number: '3.4-5'}}</h1>
  //   <h1>{{ 1.234 | number: '3.1-2'}}</h1>

  //   <h1>{{ 0.25 | percent }}</h1>

  //   <h1>{{ 50 | currency: 'INR': 'code' }}</h1>

  //   <h1>{{ date  }}</h1>
  //   <h1>{{ date | date: 'short' }}</h1>
  //   <h1>{{ date | date: 'shortDate' }}</h1>
  //   <h1>{{ date | date: 'shortTime' }}</h1>

  // `,
  templateUrl: 'test.component.html',
  styles: [`

  `]
})
export class TestComponent implements OnInit {

  public name = "Mark Smith";
  public person = {
    firstName:"Mark",
    lastName: "Smith"
  }

  public date = new Date();

  constructor() { }

  ngOnInit() {
  }





}
