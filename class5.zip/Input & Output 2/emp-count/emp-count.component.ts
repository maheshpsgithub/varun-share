import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-emp-count',
  templateUrl: './emp-count.component.html',
  styleUrls: ['./emp-count.component.css']
})
export class EmpCountComponent implements OnInit {

  @Input()
  public all;
  @Input()
  public male;
  @Input()
  public female;


  constructor() { }

  ngOnInit() {
  }

}
