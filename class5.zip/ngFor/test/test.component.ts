import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  template: `

  <ul>
    <li *ngFor="let color of colors">
      {{ color }}
    </li>
  </ul>

  <app-employee-list></app-employee-list>
  `,
  styles: [`

  `]
})
export class TestComponent implements OnInit {

  public colors = ['red', 'orange', 'green', 'yellow'];

  constructor() { }

  ngOnInit() {
  }





}
