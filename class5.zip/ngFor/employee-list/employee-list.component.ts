import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  public employees = [
    { empId: 1, name: 'Mark', gender: 'Male', salary: 5000 },
    { empId: 2, name: 'Paul', gender: 'Male', salary: 7000 },
    { empId: 3, name: 'Smith', gender: 'Male', salary: 4000 },
    { empId: 4, name: 'Watson', gender: 'Male', salary: 6000 }
  ];

  constructor() { }

  ngOnInit() {
  }

}
