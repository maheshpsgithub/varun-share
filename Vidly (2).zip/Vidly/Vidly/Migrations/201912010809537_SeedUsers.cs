namespace Vidly.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class SeedUsers : DbMigration
    {
        public override void Up()
        {
            Sql(@"
INSERT INTO [dbo].[AspNetUsers] ([Id], [DrivingLicense], [Phone], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'8d4e32a7-9fbb-4d6c-ad69-c5a13e810e0f', N'12122', N'1233454511', N'guest@vidly.com', 0, N'AKHOXkoN0uplGuEMT9My3I6r2PYvJBAzUeWSeh6bkr+p9P/Pw9k0TJWReCbwytwHUg==', N'017ae9bb-2700-4f36-8713-5cfc1aa9bb33', NULL, 0, 0, NULL, 1, 0, N'guest@vidly.com')
INSERT INTO [dbo].[AspNetUsers] ([Id], [DrivingLicense], [Phone], [Email], [EmailConfirmed], [PasswordHash], [SecurityStamp], [PhoneNumber], [PhoneNumberConfirmed], [TwoFactorEnabled], [LockoutEndDateUtc], [LockoutEnabled], [AccessFailedCount], [UserName]) VALUES (N'91462ad9-54ea-484a-aac0-acb31dd4479c', N'12121212', N'1233454511', N'admin@vidly.com', 0, N'AJi9IkT3RcheOEa8830X6+k62kfMGrXLLipnB/TM+iG+vUd75EDh6wHqHtxCYQ26Jw==', N'1228bc48-5ce2-4c70-b54b-0a89a238a1c6', NULL, 0, 0, NULL, 1, 0, N'admin@vidly.com')


INSERT INTO [dbo].[AspNetRoles] ([Id], [Name]) VALUES (N'fc422d9c-c8bc-4d93-8ed2-ea6e3774f822', N'CanManageMovies')

INSERT INTO [dbo].[AspNetUserRoles] ([UserId], [RoleId]) VALUES (N'91462ad9-54ea-484a-aac0-acb31dd4479c', N'fc422d9c-c8bc-4d93-8ed2-ea6e3774f822')

");
        }

        public override void Down()
        {
        }
    }
}
