# Services

1. When we want to share common data accross the application
2. business logic
3. for making any external interaction with the rest api

Problem:
1. Single class responsibility
2. DRY (DO not reapeat yourself)


Services are singleton class which get instantiated when we start the application
we can register service with 
Root Module
Parent COmponent 
Child COmponent


# Steps
> create a servivce
    
    ng g s <service>   // ng g s employee

> regsiter a service

   providers: []
   @injectable({providIn: 'root'})

> consume a service
	add the service as a dependency for the component
        in the constructor





# Dependency injection


class A{
  test(){
}
}

obj = new A();
obj.test()


// code without DI
// code with DI


class Engine{
}

class Tires{
}

class Car{
 engine;
 tires;

  constructor(engine, tires){
	
  }

}





# Http
steps:
1. Import HTTPClientModule in the app root
2. Import HttpClient in the servive
3. Inject HttpoClient as the dependency for the service using constructor
4. create a method and choose get / post method and pass the URL
5. in the component subscribe() to comsume the data

# Obervable
> A sequence of item that arrive asynchronously over time
> Http call - single item


# Rxjs
- Reactive extension for java script
- External library to work with observable




# Forms
Forms are essential part for any application
user can interact with your application using forms
we can take the input from the user using forms


# We can create forms in 2 ways
1. Template Driven Forms
2. Model Driven Forms or Reactive Forms



TDF - heavy work is done on the component template
Reactive forms - heavy work is done at component class


# Template Driven Forms
> east to use and similar to angular js forms
> Two way binding can be achienve by ngModel
> Bulky html and minimum component class code
> Automatically track the from and form element state and validity
> unit testing is a challenge
> readabilty decreases with complex form and validations
> suitable for simple forms


# Template Driven Forms (TDF)

# Steps
1. Add hTML in the component
2. Binding Data
3. Track state and validation
4. Display Error message
5. submit the form



<div ngModelGroup="address">
      <input type="text" name="city" ngModel class="form-control">
      <input type="text" name="state" ngModel class="form-control">
      <input type="text" name="country" ngModel class="form-control">
    </div>


# form state
Untouched - after form load element never been touched
touched - after form load element been touched
dirty - after form load element value modified
pristine - after form load element value never modified
valid - value is valid
invalid - value is invalid

# angular to track form state add or remove these 6 classes
dynamically

ng-touched        touched           true    false
ng-untouched       untouched         true    false
ng-dirty           dirty
ng-pristine        pristine
ng-valid           valid
ng-invalid         invalid









































































