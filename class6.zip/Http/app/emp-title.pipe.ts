import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'empTitle'
})
export class EmpTitlePipe implements PipeTransform {

  transform(name: any, gender: any): any {
    if(gender == 'Male'){
      return "Mr."+ name;
    }else{
      return "Mrs."+ name;
    }
  }

}
