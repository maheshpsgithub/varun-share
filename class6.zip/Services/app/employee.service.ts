import { Injectable } from '@angular/core';

@Injectable()
export class EmployeeService {

  constructor() { }

  getEmployees() {
    return [
      { empId: 1, name: 'Mark', gender: 'Male', salary: 5000, dateOfBirth: '12/25/2000' },
      { empId: 2, name: 'Paul', gender: 'Male', salary: 7000, dateOfBirth: '11/12/2000' },
      { empId: 3, name: 'Smith', gender: 'Female', salary: 4000, dateOfBirth: '12/12/2000' },
      { empId: 4, name: 'Watson', gender: 'Male', salary: 6000, dateOfBirth: '06/12/2000' },
      { empId: 5, name: 'Shaw', gender: 'Female', salary: 8000, dateOfBirth: '01/01/2000' },
      { empId: 6, name: 'Mark', gender: 'Male', salary: 5000, dateOfBirth: '12/25/2000' },
    ];
  }
}
